# KAZCHROME Android Wrapper

Это исходник оболочки Android для опубликованной веб-версии.

Перед сборкой замените `START_URL` в `MainActivity.java` на HTTPS-адрес вашей игры.

Требования: Android Studio + Android SDK + Gradle.
