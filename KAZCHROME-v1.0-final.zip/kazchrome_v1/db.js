const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'kazchrome.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS players (
  player_id TEXT PRIMARY KEY,
  name TEXT NOT NULL DEFAULT 'Игрок',
  coins INTEGER NOT NULL DEFAULT 0,
  best_score INTEGER NOT NULL DEFAULT 0,
  games_played INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS game_sessions (
  id TEXT PRIMARY KEY,
  player_id TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  earned_coins INTEGER NOT NULL DEFAULT 0,
  earned_score INTEGER NOT NULL DEFAULT 0,
  last_checkpoint_at INTEGER,
  FOREIGN KEY (player_id) REFERENCES players(player_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_players_best_score ON players(best_score DESC);
CREATE INDEX IF NOT EXISTS idx_players_coins ON players(coins DESC);
CREATE INDEX IF NOT EXISTS idx_sessions_player ON game_sessions(player_id);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON game_sessions(player_id, finished_at);
`);
module.exports = db;
