# KAZCHROME v1.0

Самостоятельная игра KAZCHROME для Web/PWA и отдельной Android-упаковки.

Архитектура: Node.js + Express + SQLite + Canvas + PWA.
